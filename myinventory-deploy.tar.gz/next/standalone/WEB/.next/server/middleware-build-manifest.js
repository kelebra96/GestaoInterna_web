globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/7c862e0a789266c5.js",
    "static/chunks/391fc237abd39b98.js",
    "static/chunks/b007ba0a450444bc.js",
    "static/chunks/06fc160ca92e5a75.js",
    "static/chunks/778cb182b81f1c41.js",
    "static/chunks/turbopack-683f592cbdd2c3dc.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];