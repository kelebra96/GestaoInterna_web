module.exports=[37164,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_promotions_%5Bid%5D_route_actions_dd93e3f5.js.map