module.exports=[91563,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_lojas_route_actions_cf94a3f7.js.map