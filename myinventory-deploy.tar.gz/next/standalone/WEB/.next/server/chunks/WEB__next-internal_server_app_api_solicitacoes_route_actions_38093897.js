module.exports=[82759,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_solicitacoes_route_actions_38093897.js.map