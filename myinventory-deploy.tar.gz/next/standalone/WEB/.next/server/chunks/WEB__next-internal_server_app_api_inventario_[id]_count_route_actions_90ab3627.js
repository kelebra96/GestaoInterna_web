module.exports=[33858,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_inventario_%5Bid%5D_count_route_actions_90ab3627.js.map