module.exports=[87019,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_dashboard_route_actions_ece6788e.js.map