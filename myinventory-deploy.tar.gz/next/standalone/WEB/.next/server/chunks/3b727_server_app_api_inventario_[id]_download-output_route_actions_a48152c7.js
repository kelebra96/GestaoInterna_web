module.exports=[4100,(e,o,d)=>{}];

//# sourceMappingURL=3b727_server_app_api_inventario_%5Bid%5D_download-output_route_actions_a48152c7.js.map