module.exports=[84230,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_inventario_%5Bid%5D_delete_route_actions_009567dd.js.map