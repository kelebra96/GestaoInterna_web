module.exports=[57596,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_products_%5Bid%5D_route_actions_bc6cad69.js.map