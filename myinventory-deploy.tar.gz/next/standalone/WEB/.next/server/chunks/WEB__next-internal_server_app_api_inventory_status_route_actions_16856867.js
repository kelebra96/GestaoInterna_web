module.exports=[27030,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_inventory_status_route_actions_16856867.js.map