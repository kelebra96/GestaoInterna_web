module.exports=[16393,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_solicitacoes_%5Bid%5D_route_actions_bcea6125.js.map