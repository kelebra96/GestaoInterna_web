module.exports=[55686,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_features_route_actions_94682e04.js.map