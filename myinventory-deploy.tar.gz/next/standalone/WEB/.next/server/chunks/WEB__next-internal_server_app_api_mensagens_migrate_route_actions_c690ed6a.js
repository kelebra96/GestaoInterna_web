module.exports=[54678,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_mensagens_migrate_route_actions_c690ed6a.js.map