module.exports=[27608,(e,o,d)=>{}];

//# sourceMappingURL=6587a__next-internal_server_app_api_volumetria_perda-receita_route_actions_888351da.js.map