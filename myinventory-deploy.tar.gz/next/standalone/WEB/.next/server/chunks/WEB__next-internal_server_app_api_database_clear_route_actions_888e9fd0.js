module.exports=[430,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_database_clear_route_actions_888e9fd0.js.map