module.exports=[55349,(e,o,d)=>{}];

//# sourceMappingURL=6587a__next-internal_server_app_api_rupture_top-lost-revenue_route_actions_91e50d88.js.map