module.exports=[61111,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_icon_png_route_actions_2ed84cbe.js.map