module.exports=[68462,(e,o,d)=>{}];

//# sourceMappingURL=6587a__next-internal_server_app_api_inventario_%5Bid%5D_finalize_route_actions_de6ab085.js.map