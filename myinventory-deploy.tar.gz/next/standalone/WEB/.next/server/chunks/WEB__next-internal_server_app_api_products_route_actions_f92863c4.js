module.exports=[60732,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_products_route_actions_f92863c4.js.map