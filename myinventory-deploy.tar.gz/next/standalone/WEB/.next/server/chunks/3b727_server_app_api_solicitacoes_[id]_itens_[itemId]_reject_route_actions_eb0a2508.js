module.exports=[44435,(e,o,d)=>{}];

//# sourceMappingURL=3b727_server_app_api_solicitacoes_%5Bid%5D_itens_%5BitemId%5D_reject_route_actions_eb0a2508.js.map