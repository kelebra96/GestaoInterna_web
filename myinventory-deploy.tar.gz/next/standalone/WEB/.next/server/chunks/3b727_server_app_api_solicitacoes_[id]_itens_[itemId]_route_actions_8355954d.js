module.exports=[19650,(e,o,d)=>{}];

//# sourceMappingURL=3b727_server_app_api_solicitacoes_%5Bid%5D_itens_%5BitemId%5D_route_actions_8355954d.js.map