module.exports=[90501,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_config_storage_route_actions_9f3625ea.js.map