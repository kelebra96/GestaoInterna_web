module.exports=[77526,(e,o,d)=>{}];

//# sourceMappingURL=3b727_server_app_api_solicitacoes_%5Bid%5D_itens_%5BitemId%5D_approve_route_actions_dff4b638.js.map