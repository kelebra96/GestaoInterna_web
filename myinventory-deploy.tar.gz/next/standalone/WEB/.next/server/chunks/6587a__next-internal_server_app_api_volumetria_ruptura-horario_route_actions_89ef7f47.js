module.exports=[22245,(e,o,d)=>{}];

//# sourceMappingURL=6587a__next-internal_server_app_api_volumetria_ruptura-horario_route_actions_89ef7f47.js.map