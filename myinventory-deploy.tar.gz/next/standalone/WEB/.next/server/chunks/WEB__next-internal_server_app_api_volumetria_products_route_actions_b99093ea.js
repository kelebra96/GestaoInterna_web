module.exports=[5411,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_volumetria_products_route_actions_b99093ea.js.map