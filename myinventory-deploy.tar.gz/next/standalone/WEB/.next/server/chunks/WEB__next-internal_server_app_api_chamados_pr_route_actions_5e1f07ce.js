module.exports=[28705,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_chamados_pr_route_actions_5e1f07ce.js.map