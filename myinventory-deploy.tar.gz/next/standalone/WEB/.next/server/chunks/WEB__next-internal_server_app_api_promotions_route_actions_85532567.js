module.exports=[56940,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_promotions_route_actions_85532567.js.map