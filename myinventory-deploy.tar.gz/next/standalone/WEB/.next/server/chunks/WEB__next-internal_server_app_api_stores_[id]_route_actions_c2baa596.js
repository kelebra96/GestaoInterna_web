module.exports=[22112,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_stores_%5Bid%5D_route_actions_c2baa596.js.map