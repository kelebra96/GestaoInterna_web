module.exports=[9403,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_shelves_route_actions_7b32ad4b.js.map