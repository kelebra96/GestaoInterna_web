module.exports=[4753,(e,o,d)=>{}];

//# sourceMappingURL=3b727_server_app_api_volumetria_status-abastecimento_route_actions_a250f4ef.js.map