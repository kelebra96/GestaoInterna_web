module.exports=[65745,(e,o,d)=>{}];

//# sourceMappingURL=6587a__next-internal_server_app_api_inventario_%5Bid%5D_addresses_route_actions_d7d76662.js.map