module.exports=[31055,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_solicitacoes_%5Bid%5D_itens_route_actions_0ae5606a.js.map