module.exports=[75361,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_empresas_route_actions_5f0ad6bf.js.map