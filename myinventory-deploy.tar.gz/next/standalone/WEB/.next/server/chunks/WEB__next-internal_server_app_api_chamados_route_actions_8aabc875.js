module.exports=[33531,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_chamados_route_actions_8aabc875.js.map