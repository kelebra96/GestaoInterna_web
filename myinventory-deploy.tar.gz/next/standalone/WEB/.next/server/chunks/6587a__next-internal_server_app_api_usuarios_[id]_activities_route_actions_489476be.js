module.exports=[36075,(e,o,d)=>{}];

//# sourceMappingURL=6587a__next-internal_server_app_api_usuarios_%5Bid%5D_activities_route_actions_489476be.js.map