module.exports=[80790,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_inventario_%5Bid%5D_route_actions_43820aee.js.map