module.exports=[46185,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_companies_route_actions_d0ee71b5.js.map