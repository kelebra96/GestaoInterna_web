module.exports=[22938,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_mensagens_%5Bid%5D_route_actions_b1bd5f56.js.map