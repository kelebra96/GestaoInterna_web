module.exports=[55698,(e,o,d)=>{}];

//# sourceMappingURL=3b727_server_app_api_inventario_%5Bid%5D_addresses_generate_route_actions_d47b320d.js.map