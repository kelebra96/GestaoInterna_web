module.exports=[63731,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_inventario_route_actions_4cb3e015.js.map