module.exports=[66843,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_notificacoes_route_actions_8a81e312.js.map