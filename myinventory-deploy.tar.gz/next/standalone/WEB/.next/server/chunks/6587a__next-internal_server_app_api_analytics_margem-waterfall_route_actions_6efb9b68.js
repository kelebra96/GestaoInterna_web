module.exports=[85570,(e,o,d)=>{}];

//# sourceMappingURL=6587a__next-internal_server_app_api_analytics_margem-waterfall_route_actions_6efb9b68.js.map