module.exports=[2732,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_planograms_analytics_route_actions_368ea4ce.js.map