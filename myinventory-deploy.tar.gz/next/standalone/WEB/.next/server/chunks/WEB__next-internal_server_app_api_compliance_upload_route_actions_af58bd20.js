module.exports=[99675,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_compliance_upload_route_actions_af58bd20.js.map