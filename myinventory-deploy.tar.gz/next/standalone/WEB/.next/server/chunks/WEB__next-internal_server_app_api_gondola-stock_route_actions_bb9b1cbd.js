module.exports=[11374,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_gondola-stock_route_actions_bb9b1cbd.js.map