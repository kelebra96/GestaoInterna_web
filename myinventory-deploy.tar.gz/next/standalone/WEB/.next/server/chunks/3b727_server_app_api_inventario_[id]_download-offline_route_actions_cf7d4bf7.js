module.exports=[89483,(e,o,d)=>{}];

//# sourceMappingURL=3b727_server_app_api_inventario_%5Bid%5D_download-offline_route_actions_cf7d4bf7.js.map