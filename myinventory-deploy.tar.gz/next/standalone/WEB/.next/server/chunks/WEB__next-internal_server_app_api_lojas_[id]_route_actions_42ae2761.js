module.exports=[17645,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_lojas_%5Bid%5D_route_actions_42ae2761.js.map