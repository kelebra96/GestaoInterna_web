module.exports=[30852,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_test_route_actions_a4350cc1.js.map