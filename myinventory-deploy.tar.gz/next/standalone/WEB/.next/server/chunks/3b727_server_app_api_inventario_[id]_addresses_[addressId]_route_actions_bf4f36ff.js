module.exports=[61767,(e,o,d)=>{}];

//# sourceMappingURL=3b727_server_app_api_inventario_%5Bid%5D_addresses_%5BaddressId%5D_route_actions_bf4f36ff.js.map