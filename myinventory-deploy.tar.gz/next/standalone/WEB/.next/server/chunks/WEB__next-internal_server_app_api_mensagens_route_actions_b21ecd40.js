module.exports=[9520,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_mensagens_route_actions_b21ecd40.js.map