module.exports=[13860,(e,o,d)=>{}];

//# sourceMappingURL=3b727_server_app_api_analytics_heatmap-ruptura-horario_route_actions_1009ce6c.js.map