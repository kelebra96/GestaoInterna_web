module.exports=[66546,(e,o,d)=>{}];

//# sourceMappingURL=6587a__next-internal_server_app_api_volumetria_slots-criticos_route_actions_502828b0.js.map