module.exports=[41958,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_produtos_route_actions_50446fb4.js.map