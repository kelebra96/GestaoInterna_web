module.exports=[37702,(a,b,c)=>{b.exports=a.x("worker_threads",()=>require("worker_threads"))}];

//# sourceMappingURL=%5Bexternals%5D_worker_threads_a2f38a15._.js.map