module.exports=[26449,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_inventario_%5Bid%5D_enderecos_page_actions_06950ec8.js.map