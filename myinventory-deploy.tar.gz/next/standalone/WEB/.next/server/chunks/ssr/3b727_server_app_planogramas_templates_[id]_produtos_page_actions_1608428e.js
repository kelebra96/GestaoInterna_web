module.exports=[60402,(a,b,c)=>{}];

//# sourceMappingURL=3b727_server_app_planogramas_templates_%5Bid%5D_produtos_page_actions_1608428e.js.map