module.exports=[71097,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_analytics_page_actions_33cbc784.js.map