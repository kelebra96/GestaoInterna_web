module.exports=[67996,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_produtos_%5Bid%5D_page_actions_2c8e4cd0.js.map