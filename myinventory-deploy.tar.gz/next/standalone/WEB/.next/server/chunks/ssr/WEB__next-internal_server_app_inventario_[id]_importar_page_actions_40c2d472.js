module.exports=[11435,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_inventario_%5Bid%5D_importar_page_actions_40c2d472.js.map