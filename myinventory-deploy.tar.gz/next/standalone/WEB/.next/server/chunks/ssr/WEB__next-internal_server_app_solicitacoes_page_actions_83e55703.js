module.exports=[57393,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_solicitacoes_page_actions_83e55703.js.map