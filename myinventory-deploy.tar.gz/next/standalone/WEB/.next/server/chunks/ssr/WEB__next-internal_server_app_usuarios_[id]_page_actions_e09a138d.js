module.exports=[20780,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_usuarios_%5Bid%5D_page_actions_e09a138d.js.map