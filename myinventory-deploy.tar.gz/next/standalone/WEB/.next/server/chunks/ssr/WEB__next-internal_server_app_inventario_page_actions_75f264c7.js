module.exports=[20527,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_inventario_page_actions_75f264c7.js.map