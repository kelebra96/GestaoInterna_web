module.exports=[9859,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_inventario_%5Bid%5D_page_actions_dc0b2973.js.map