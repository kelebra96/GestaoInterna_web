module.exports=[72278,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_mensagens_%5Bid%5D_page_actions_7d1a0eb3.js.map