module.exports=[79387,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_relatorios_page_actions_4db5c070.js.map