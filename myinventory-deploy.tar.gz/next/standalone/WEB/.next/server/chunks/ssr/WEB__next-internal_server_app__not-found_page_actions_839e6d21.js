module.exports=[48073,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app__not-found_page_actions_839e6d21.js.map