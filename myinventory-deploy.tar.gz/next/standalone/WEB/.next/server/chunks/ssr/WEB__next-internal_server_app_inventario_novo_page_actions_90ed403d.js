module.exports=[52461,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_inventario_novo_page_actions_90ed403d.js.map