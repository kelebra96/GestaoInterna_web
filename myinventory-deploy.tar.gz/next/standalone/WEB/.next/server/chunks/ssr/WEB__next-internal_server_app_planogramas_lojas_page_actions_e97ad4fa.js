module.exports=[844,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_planogramas_lojas_page_actions_e97ad4fa.js.map