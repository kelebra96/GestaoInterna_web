module.exports=[5897,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_page_actions_01c28267.js.map