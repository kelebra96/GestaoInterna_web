module.exports=[60150,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_empresas_page_actions_1b517313.js.map