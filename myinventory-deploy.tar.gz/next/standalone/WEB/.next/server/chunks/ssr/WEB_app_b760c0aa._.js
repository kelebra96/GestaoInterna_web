module.exports=[9184,a=>{a.v("/_next/static/media/icon.4d5c38a9.png")},94408,a=>{"use strict";let b={src:a.i(9184).default,width:1024,height:1024};a.s(["default",0,b])}];

//# sourceMappingURL=WEB_app_b760c0aa._.js.map