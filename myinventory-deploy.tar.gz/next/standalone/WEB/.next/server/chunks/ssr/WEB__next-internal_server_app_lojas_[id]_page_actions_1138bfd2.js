module.exports=[49827,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_lojas_%5Bid%5D_page_actions_1138bfd2.js.map