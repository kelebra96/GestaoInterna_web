module.exports=[35286,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_empresas_nova_page_actions_5b8d0b3d.js.map