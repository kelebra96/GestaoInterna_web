module.exports=[58321,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_inventario_%5Bid%5D_coleta_page_actions_0191f5b8.js.map