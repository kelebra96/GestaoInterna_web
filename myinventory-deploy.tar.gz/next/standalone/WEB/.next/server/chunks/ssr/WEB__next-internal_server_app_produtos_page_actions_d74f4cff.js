module.exports=[18108,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_produtos_page_actions_d74f4cff.js.map