module.exports=[33852,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_empresas_%5Bid%5D_page_actions_2dd40e4a.js.map