module.exports=[80006,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app__global-error_page_actions_7b0a14fe.js.map