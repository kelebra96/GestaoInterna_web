module.exports=[61993,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_login_page_actions_ca9e60ab.js.map