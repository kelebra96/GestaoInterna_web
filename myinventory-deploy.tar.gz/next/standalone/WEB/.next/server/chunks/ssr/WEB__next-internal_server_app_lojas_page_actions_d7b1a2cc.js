module.exports=[80972,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_lojas_page_actions_d7b1a2cc.js.map