module.exports=[10181,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_planogramas_templates_%5Bid%5D_page_actions_04b97510.js.map