module.exports=[1926,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_configuracoes_page_actions_c6cf0956.js.map