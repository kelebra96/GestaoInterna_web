module.exports=[55215,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_perfil_page_actions_380e5d3e.js.map