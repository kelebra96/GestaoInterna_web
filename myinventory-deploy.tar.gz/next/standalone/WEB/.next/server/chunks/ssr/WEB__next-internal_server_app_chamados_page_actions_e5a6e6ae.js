module.exports=[30453,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_chamados_page_actions_e5a6e6ae.js.map