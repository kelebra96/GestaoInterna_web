module.exports=[7410,(a,b,c)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_notificacoes_page_actions_ff585bbc.js.map