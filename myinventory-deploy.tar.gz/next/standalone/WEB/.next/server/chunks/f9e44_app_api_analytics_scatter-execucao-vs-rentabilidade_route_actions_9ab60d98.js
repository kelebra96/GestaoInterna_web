module.exports=[92104,(e,o,d)=>{}];

//# sourceMappingURL=f9e44_app_api_analytics_scatter-execucao-vs-rentabilidade_route_actions_9ab60d98.js.map