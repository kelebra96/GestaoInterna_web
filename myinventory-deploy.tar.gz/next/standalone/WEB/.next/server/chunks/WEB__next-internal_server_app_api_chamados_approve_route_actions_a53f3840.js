module.exports=[1208,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_chamados_approve_route_actions_a53f3840.js.map