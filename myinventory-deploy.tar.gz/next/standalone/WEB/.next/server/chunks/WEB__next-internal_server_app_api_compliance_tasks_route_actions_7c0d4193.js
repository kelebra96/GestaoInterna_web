module.exports=[77604,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_compliance_tasks_route_actions_7c0d4193.js.map