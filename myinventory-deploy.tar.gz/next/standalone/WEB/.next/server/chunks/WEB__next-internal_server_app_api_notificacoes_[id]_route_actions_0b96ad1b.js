module.exports=[86754,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_notificacoes_%5Bid%5D_route_actions_0b96ad1b.js.map