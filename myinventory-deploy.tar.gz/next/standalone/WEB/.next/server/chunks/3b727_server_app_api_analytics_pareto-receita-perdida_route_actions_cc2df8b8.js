module.exports=[21321,(e,o,d)=>{}];

//# sourceMappingURL=3b727_server_app_api_analytics_pareto-receita-perdida_route_actions_cc2df8b8.js.map