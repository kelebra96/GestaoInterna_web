module.exports=[63785,(e,o,d)=>{}];

//# sourceMappingURL=WEB__next-internal_server_app_api_auth_register_route_actions_d48b28c5.js.map